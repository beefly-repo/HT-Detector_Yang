# cuvette_YangKaining > 2025-10-20 4:14pm
https://universe.roboflow.com/yue-snlbi/cuvette_yangkaining-ktgko

Provided by a Roboflow user
License: CC BY 4.0

